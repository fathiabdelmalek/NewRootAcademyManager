create definer = fathi@`%` view `students view` as
select `new_root_academy_manager_db`.`students`.`id`           AS `id`,
       `new_root_academy_manager_db`.`students`.`first name`   AS `first name`,
       `new_root_academy_manager_db`.`students`.`last name`    AS `last name`,
       `new_root_academy_manager_db`.`students`.`phone number` AS `phone number`,
       `new_root_academy_manager_db`.`students`.`sex`          AS `sex`,
       `new_root_academy_manager_db`.`students`.`birth date`   AS `birth date`,
       concat(`new_root_academy_manager_db`.`grades`.`year of grade`, ' ',
              `new_root_academy_manager_db`.`grades`.`level`)  AS `grade`
from (`new_root_academy_manager_db`.`students` join `new_root_academy_manager_db`.`grades`
      on ((`new_root_academy_manager_db`.`grades`.`id` = `new_root_academy_manager_db`.`students`.`grade id`)));

