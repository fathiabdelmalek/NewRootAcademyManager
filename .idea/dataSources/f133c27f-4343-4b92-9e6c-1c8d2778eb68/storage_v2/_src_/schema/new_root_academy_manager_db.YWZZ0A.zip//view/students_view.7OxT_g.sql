create definer = fathi@`%` view students_view as
select `new_root_academy_manager_db`.`students`.`id`           AS `id`,
       `new_root_academy_manager_db`.`students`.`first_name`   AS `first_name`,
       `new_root_academy_manager_db`.`students`.`last_name`    AS `last_name`,
       `new_root_academy_manager_db`.`students`.`phone_number` AS `phone_number`,
       `new_root_academy_manager_db`.`students`.`sex`          AS `sex`,
       `new_root_academy_manager_db`.`students`.`birth_date`   AS `birth_date`,
       concat(`new_root_academy_manager_db`.`grades`.`year_of_grade`, ' ',
              `new_root_academy_manager_db`.`grades`.`level`)  AS `grade`
from (`new_root_academy_manager_db`.`students` join `new_root_academy_manager_db`.`grades`
      on ((`new_root_academy_manager_db`.`grades`.`id` = `new_root_academy_manager_db`.`students`.`grade_id`)));

