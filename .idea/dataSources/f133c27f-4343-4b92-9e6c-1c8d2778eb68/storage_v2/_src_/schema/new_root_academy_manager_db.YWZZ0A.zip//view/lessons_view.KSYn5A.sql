create definer = fathi@`%` view lessons_view as
select `new_root_academy_manager_db`.`lessons`.`id`                 AS `id`,
       `new_root_academy_manager_db`.`lessons`.`lesson_name`        AS `lesson_name`,
       `new_root_academy_manager_db`.`lessons`.`price`              AS `price`,
       `new_root_academy_manager_db`.`lessons`.`classes_number`     AS `classes_number`,
       `new_root_academy_manager_db`.`lessons`.`day_of_week`        AS `day_of_week`,
       `new_root_academy_manager_db`.`lessons`.`start_time`         AS `start_time`,
       `new_root_academy_manager_db`.`lessons`.`end_time`           AS `end_time`,
       concat(`new_root_academy_manager_db`.`teachers`.`first_name`, ' ',
              `new_root_academy_manager_db`.`teachers`.`last_name`) AS `teacher_name`,
       `new_root_academy_manager_db`.`rooms`.`code`                 AS `room_code`,
       concat(`new_root_academy_manager_db`.`grades`.`year_of_grade`, ' ',
              `new_root_academy_manager_db`.`grades`.`level`)       AS `grade`,
       (select count(0)
        from `new_root_academy_manager_db`.`attendances`
        where (`new_root_academy_manager_db`.`attendances`.`lesson_id` =
               `new_root_academy_manager_db`.`lessons`.`id`))       AS `students_number`
from (((`new_root_academy_manager_db`.`lessons` join `new_root_academy_manager_db`.`teachers`
        on ((`new_root_academy_manager_db`.`teachers`.`id` =
             `new_root_academy_manager_db`.`lessons`.`teacher_id`))) join `new_root_academy_manager_db`.`rooms`
       on ((`new_root_academy_manager_db`.`rooms`.`id` =
            `new_root_academy_manager_db`.`lessons`.`room_id`))) left join `new_root_academy_manager_db`.`grades`
      on ((`new_root_academy_manager_db`.`grades`.`id` = `new_root_academy_manager_db`.`lessons`.`grade_id`)));

