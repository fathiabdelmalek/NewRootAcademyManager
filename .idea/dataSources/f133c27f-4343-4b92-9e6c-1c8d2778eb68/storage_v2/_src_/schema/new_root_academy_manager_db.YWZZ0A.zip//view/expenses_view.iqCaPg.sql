create definer = fathi@`%` view `expenses view` as
select `new_root_academy_manager_db`.`expenses`.`id`                AS `id`,
       `new_root_academy_manager_db`.`expenses`.`amount`            AS `amount`,
       `new_root_academy_manager_db`.`expenses`.`details`           AS `details`,
       `new_root_academy_manager_db`.`expenses`.`create time`       AS `time`,
       concat(`new_root_academy_manager_db`.`teachers`.`first name`, ' ',
              `new_root_academy_manager_db`.`teachers`.`last name`) AS `teacher name`
from (`new_root_academy_manager_db`.`expenses` left join `new_root_academy_manager_db`.`teachers`
      on ((`new_root_academy_manager_db`.`teachers`.`id` = `new_root_academy_manager_db`.`expenses`.`teacher id`)))
order by `new_root_academy_manager_db`.`expenses`.`create time` desc;

