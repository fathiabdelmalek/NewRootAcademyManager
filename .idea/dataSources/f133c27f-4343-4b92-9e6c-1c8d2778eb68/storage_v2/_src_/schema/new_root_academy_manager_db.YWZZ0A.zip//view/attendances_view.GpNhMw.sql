create definer = fathi@`%` view attendances_view as
select `new_root_academy_manager_db`.`attendances`.`id`             AS `id`,
       `new_root_academy_manager_db`.`attendances`.`lesson_id`      AS `lesson_id`,
       `new_root_academy_manager_db`.`attendances`.`student_id`     AS `student_id`,
       `new_root_academy_manager_db`.`lessons`.`lesson_name`        AS `lesson_name`,
       concat(`new_root_academy_manager_db`.`students`.`first_name`, ' ',
              `new_root_academy_manager_db`.`students`.`last_name`) AS `student_name`,
       `new_root_academy_manager_db`.`attendances`.`times_present`  AS `times_present`,
       `new_root_academy_manager_db`.`attendances`.`notes`          AS `notes`,
       `new_root_academy_manager_db`.`attendances`.`dues`           AS `dues`
from ((`new_root_academy_manager_db`.`attendances` join `new_root_academy_manager_db`.`students`
       on ((`new_root_academy_manager_db`.`students`.`id` =
            `new_root_academy_manager_db`.`attendances`.`student_id`))) join `new_root_academy_manager_db`.`lessons`
      on ((`new_root_academy_manager_db`.`lessons`.`id` = `new_root_academy_manager_db`.`attendances`.`lesson_id`)));

