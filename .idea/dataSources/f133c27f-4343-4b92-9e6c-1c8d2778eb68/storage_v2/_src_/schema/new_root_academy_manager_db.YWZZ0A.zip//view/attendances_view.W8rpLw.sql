create definer = fathi@`%` view `attendances view` as
select `new_root_academy_manager_db`.`attendances`.`id`             AS `id`,
       `new_root_academy_manager_db`.`attendances`.`lesson id`      AS `lesson id`,
       `new_root_academy_manager_db`.`attendances`.`student id`     AS `student id`,
       `new_root_academy_manager_db`.`lessons`.`lesson name`        AS `lesson name`,
       concat(`new_root_academy_manager_db`.`students`.`first name`, ' ',
              `new_root_academy_manager_db`.`students`.`last name`) AS `student name`,
       `new_root_academy_manager_db`.`attendances`.`times present`  AS `times present`,
       `new_root_academy_manager_db`.`attendances`.`notes`          AS `notes`,
       `new_root_academy_manager_db`.`attendances`.`dues`           AS `dues`
from ((`new_root_academy_manager_db`.`attendances` join `new_root_academy_manager_db`.`students`
       on ((`new_root_academy_manager_db`.`students`.`id` =
            `new_root_academy_manager_db`.`attendances`.`student id`))) join `new_root_academy_manager_db`.`lessons`
      on ((`new_root_academy_manager_db`.`lessons`.`id` = `new_root_academy_manager_db`.`attendances`.`lesson id`)));

