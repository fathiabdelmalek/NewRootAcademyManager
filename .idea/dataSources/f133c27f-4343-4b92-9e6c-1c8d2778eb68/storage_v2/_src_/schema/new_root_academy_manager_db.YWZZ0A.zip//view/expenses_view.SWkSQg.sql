create definer = fathi@`%` view expenses_view as
select `new_root_academy_manager_db`.`expenses`.`id`                AS `id`,
       `new_root_academy_manager_db`.`expenses`.`amount`            AS `amount`,
       `new_root_academy_manager_db`.`expenses`.`details`           AS `details`,
       `new_root_academy_manager_db`.`expenses`.`create_time`       AS `time`,
       concat(`new_root_academy_manager_db`.`teachers`.`first_name`, ' ',
              `new_root_academy_manager_db`.`teachers`.`last_name`) AS `teacher_name`
from (`new_root_academy_manager_db`.`expenses` left join `new_root_academy_manager_db`.`teachers`
      on ((`new_root_academy_manager_db`.`teachers`.`id` = `new_root_academy_manager_db`.`expenses`.`teacher_id`)))
order by `new_root_academy_manager_db`.`expenses`.`create_time` desc;

