create definer = fathi@`%` view `incomes view` as
select `new_root_academy_manager_db`.`incomes`.`id`                 AS `id`,
       `new_root_academy_manager_db`.`incomes`.`amount`             AS `amount`,
       `new_root_academy_manager_db`.`incomes`.`details`            AS `details`,
       `new_root_academy_manager_db`.`incomes`.`create time`        AS `time`,
       concat(`new_root_academy_manager_db`.`students`.`first name`, ' ',
              `new_root_academy_manager_db`.`students`.`last name`) AS `student name`
from (`new_root_academy_manager_db`.`incomes` left join `new_root_academy_manager_db`.`students`
      on ((`new_root_academy_manager_db`.`students`.`id` = `new_root_academy_manager_db`.`incomes`.`student id`)))
order by `new_root_academy_manager_db`.`incomes`.`create time` desc;

