create definer = fathi@`%` view `lessons view` as
select `new_root_academy_manager_db`.`lessons`.`id`                 AS `id`,
       `new_root_academy_manager_db`.`lessons`.`lesson name`        AS `lesson name`,
       `new_root_academy_manager_db`.`lessons`.`price`              AS `price`,
       `new_root_academy_manager_db`.`lessons`.`classes number`     AS `classes number`,
       `new_root_academy_manager_db`.`lessons`.`day of week`        AS `day of week`,
       `new_root_academy_manager_db`.`lessons`.`start time`         AS `start time`,
       `new_root_academy_manager_db`.`lessons`.`end time`           AS `end time`,
       concat(`new_root_academy_manager_db`.`teachers`.`first name`, ' ',
              `new_root_academy_manager_db`.`teachers`.`last name`) AS `teacher name`,
       `new_root_academy_manager_db`.`rooms`.`code`                 AS `room code`,
       concat(`new_root_academy_manager_db`.`grades`.`year of grade`, ' ',
              `new_root_academy_manager_db`.`grades`.`level`)       AS `grade`,
       (select count(0)
        from `new_root_academy_manager_db`.`attendances`
        where (`new_root_academy_manager_db`.`attendances`.`lesson id` =
               `new_root_academy_manager_db`.`lessons`.`id`))       AS `students number`
from (((`new_root_academy_manager_db`.`lessons` join `new_root_academy_manager_db`.`teachers`
        on ((`new_root_academy_manager_db`.`teachers`.`id` =
             `new_root_academy_manager_db`.`lessons`.`teacher id`))) join `new_root_academy_manager_db`.`rooms`
       on ((`new_root_academy_manager_db`.`rooms`.`id` =
            `new_root_academy_manager_db`.`lessons`.`room id`))) left join `new_root_academy_manager_db`.`grades`
      on ((`new_root_academy_manager_db`.`grades`.`id` = `new_root_academy_manager_db`.`lessons`.`grade id`)));

