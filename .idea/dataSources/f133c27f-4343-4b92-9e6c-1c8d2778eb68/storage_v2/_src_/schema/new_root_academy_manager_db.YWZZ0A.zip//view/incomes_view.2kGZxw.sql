create definer = fathi@`%` view incomes_view as
select `new_root_academy_manager_db`.`incomes`.`id`                 AS `id`,
       `new_root_academy_manager_db`.`incomes`.`amount`             AS `amount`,
       `new_root_academy_manager_db`.`incomes`.`details`            AS `details`,
       `new_root_academy_manager_db`.`incomes`.`create_time`        AS `time`,
       concat(`new_root_academy_manager_db`.`students`.`first_name`, ' ',
              `new_root_academy_manager_db`.`students`.`last_name`) AS `student_name`
from (`new_root_academy_manager_db`.`incomes` left join `new_root_academy_manager_db`.`students`
      on ((`new_root_academy_manager_db`.`students`.`id` = `new_root_academy_manager_db`.`incomes`.`student_id`)))
order by `new_root_academy_manager_db`.`incomes`.`create_time` desc;

