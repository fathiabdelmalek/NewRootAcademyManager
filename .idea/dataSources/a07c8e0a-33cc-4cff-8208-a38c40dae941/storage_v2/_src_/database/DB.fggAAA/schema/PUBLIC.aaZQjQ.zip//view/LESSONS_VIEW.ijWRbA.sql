CREATE FORCE VIEW "PUBLIC"."LESSONS VIEW"
            ("ID", "LESSON NAME", "PRICE", "CLASSES NUMBER", "DAY", "START TIME", "END TIME", "TEACHER NAME",
             "ROOM CODE", "GRADE", "STUDENTS NUMBER")
AS
SELECT "LESSONS"."ID",
       "LESSONS"."LESSON NAME",
       "LESSONS"."PRICE",
       "LESSONS"."CLASSES NUMBER",
       "LESSONS"."DAY",
       "LESSONS"."START TIME",
       "LESSONS"."END TIME",
       CONCAT("TEACHERS"."FIRST NAME", ' ', "TEACHERS"."LAST NAME") AS "TEACHER NAME",
       "ROOMS"."CODE"                                               AS "ROOM CODE",
       CONCAT("GRADES"."YEAR", ' ', "GRADES"."LEVEL")               AS "GRADE",
       (SELECT COUNT(*)
        FROM "PUBLIC"."ATTENDANCES"
        WHERE "ATTENDANCES"."LESSON ID" = "LESSONS"."ID")           AS "STUDENTS NUMBER"
FROM "PUBLIC"."LESSONS"
         INNER JOIN "PUBLIC"."TEACHERS"
                    ON 1 = 1
         INNER JOIN "PUBLIC"."ROOMS"
                    ON 1 = 1
         LEFT OUTER JOIN "PUBLIC"."GRADES"
                         ON "GRADES"."ID" = "LESSONS"."GRADE ID"
WHERE ("ROOMS"."ID" = "LESSONS"."ROOM ID")
  AND ("TEACHERS"."ID" = "LESSONS"."TEACHER ID");

